The application, Findr, has been built using MEAN stack. 
Live URL:  https://findr-8172c.web.app/

Please run the command "npm install" inside both the directories:
1. zensar-frontend
2. zensar-backend

In the backend:

Run "node main.js"

In the frontend:

Run "ng serve --open"


------------------------
Author - Avranil Maity
------------------------